------------------------ 
The used environment is:
------------------------ 
+ KUbuntu 16
+ Konsole
+ Firefox
+ bash

+ PHP 7.2.33 (CLI)
+ Python 3.5.2
+ Python-Mutagen 1.31
+  mid3v2 and mid3cp (part of Mutagen)


Some are prerequisites (like PHP, Python and Mutagen), others are interchangeable. For example, if you use Chromium instead of Firefox you must edit the shell scripts or do the steps manually. 

